﻿using Microsoft.EntityFrameworkCore;
using ProductManagement.Models;

namespace ProductManagement.Data
{
	public class ApplicationDbContext: DbContext
	{
		public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options) : base(options) { }

		public DbSet<Product> Products { get; set; }
		public DbSet<Category> Categories { get; set; }
		public DbSet<ProductCategory> ProductCategories { get; set; }
		public DbSet<Order> Orders { get; set; }
		public DbSet<ProductReview> ProductReview { get; set; }

		protected override void OnModelCreating(ModelBuilder modelBuilder)
		{
			
			modelBuilder.Entity<ProductCategory>()
				.HasKey(pc => new { pc.ProductID, pc.CategoryID });

			modelBuilder.Entity<ProductCategory>()
				.HasOne(pc => pc.Product)
				.WithMany(p => p.ProductCategories)
				.HasForeignKey(pc => pc.ProductID)
			.OnDelete(DeleteBehavior.ClientSetNull);

			modelBuilder.Entity<ProductCategory>()
				.HasOne(pc => pc.Category)
				.WithMany(c => c.ProductCategories)
				.HasForeignKey(pc => pc.CategoryID)
			.OnDelete(DeleteBehavior.ClientSetNull);

			modelBuilder.Entity<Product>()
				.HasOne(p => p.Category)
				.WithMany(c => c.Products)
				.HasForeignKey(p => p.CategoryID)
				.OnDelete(DeleteBehavior.Restrict); 

			modelBuilder.Entity<ProductReview>()
				.HasKey(pr => pr.ReviewID);

			modelBuilder.Entity<ProductReview>()
				.HasOne(pr => pr.Product)
				.WithMany(p => p.Reviews)
				.HasForeignKey(pr => pr.ProductID)
				.OnDelete(DeleteBehavior.Cascade); 

			modelBuilder.Entity<ProductReview>()
				.Property(r => r.UserID)
				.HasDefaultValueSql("ABS(CHECKSUM(NEWID())) % 10000");

			base.OnModelCreating(modelBuilder);
		}
	}
}
