﻿using System.ComponentModel.DataAnnotations;

namespace ProductManagement.Models
{
	public class Order
	{
		public int OrderID { get; set; }

		[Required]
		public int ProductID { get; set; }

		[Required]
		[Range(1, int.MaxValue, ErrorMessage = "Quantity must be at least 1.")]
		public int Quantity { get; set; }

		public decimal TotalPrice { get; set; }

		public DateTime OrderDate { get; set; } = DateTime.Now;

		public Product Product { get; set; }
	}
}
