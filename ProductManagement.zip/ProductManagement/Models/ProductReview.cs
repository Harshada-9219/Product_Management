﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace ProductManagement.Models
{
	public class ProductReview
	{
		[Key]
		public int ReviewID { get; set; }
		[Required]
		public int ProductID { get; set; }
		[Required]
		public int UserID { get; set; }
		[Required]
		[Range(1, 5, ErrorMessage = "Rating must be between 1 and 5.")]
		public int Rating { get; set; }
		[Required]
		[MaxLength(500)]
		public string Comment { get; set; }
		[Required]
		[MaxLength(10)]
		public string Sentiment { get; set; }  
		public DateTime CreatedAt { get; set; } = DateTime.Now;
		[ForeignKey("ProductID")]
		public Product Product { get; set; }
	}
}
