﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ProductManagement.Data;
using ProductManagement.Models;

namespace ProductManagement.Controllers
{
	public class ReviewController : Controller
	{
		private readonly ApplicationDbContext _context;

		public ReviewController(ApplicationDbContext context)
		{
			_context = context;
		}
		public async Task<IActionResult> Index()
		{
			var reviews = await _context.ProductReview.Include(r => r.Product).ToListAsync();
			ViewBag.Products = await _context.Products.ToListAsync();
			return View(reviews);
		}

		public async Task<IActionResult> Add(int productId)
		{

			var product = await _context.Products.FindAsync(productId);
			if (product == null)
				return NotFound();

			ViewBag.Product = product;
			return View();
		}

		// Post method to Handle review submission
		[HttpPost]
		public async Task<IActionResult> Create(ProductReview review)
		{
			if (review.Rating >= 4)
			{
				review.Sentiment = "Positive";
				TempData["Success"] = "Thank you for your feedback! 🎉 You've earned a loyalty reward!";
			}
			else if (review.Rating == 3)
			{
				review.Sentiment = "Neutral";
				TempData["Info"] = "Thank you for your feedback. We appreciate your thoughts!";
			}
			else
			{
				review.Sentiment = "Negative";
				TempData["Error"] = "We're sorry for your experience. 😔 We will work on improving!";
			}

			_context.ProductReview.Add(review);
			await _context.SaveChangesAsync();

			return RedirectToAction("Index");
		}
	}
}

