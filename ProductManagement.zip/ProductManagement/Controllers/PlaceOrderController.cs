﻿using Microsoft.AspNetCore.Mvc;
using ProductManagement.Data;
using ProductManagement.Models;
using Microsoft.EntityFrameworkCore;

namespace ProductManagement.Controllers
{
    public class PlaceOrderController : Controller
    {
		private readonly ApplicationDbContext _context;

		public PlaceOrderController(ApplicationDbContext context)
		{
			_context = context;
		}

		// GET methd to Show Order Form 
		public async Task<IActionResult> Create(int productId)
		{
			var product = await _context.Products.FindAsync(productId);
			if (product == null)
				return NotFound();

			ViewBag.Product = product;
			return View();
		}

		// POST methd to Place Order
		[HttpPost]
		public async Task<IActionResult> Create(Order order)
		{
			var product = await _context.Products.FindAsync(order.ProductID);

			if (product == null || order.Quantity > product.StockQuantity)
			{
				TempData["Error"] = "Not enough stock available!";
				return RedirectToAction("Index", "Product");
			}

			order.TotalPrice = order.Quantity * product.Price;

			// when place the order,Reduce stock quantity in ProductController
			product.StockQuantity -= order.Quantity;

			_context.Orders.Add(order);
			await _context.SaveChangesAsync();

			TempData["Success"] = "Order placed successfully!";
			return RedirectToAction("Index", "Product");
		}

		//GET method to List All Orders
		public async Task<IActionResult> Index()
		{
			var orders = await _context.Orders.Include(o => o.Product).ToListAsync();
			return View(orders);
		}
	}
}
