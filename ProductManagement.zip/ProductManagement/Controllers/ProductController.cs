﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ProductManagement.Data;
using ProductManagement.Models;

namespace ProductManagement.Controllers
{
	public class ProductController : Controller
	{
		private readonly ApplicationDbContext _context;

		public ProductController(ApplicationDbContext context)
		{
			_context = context;
		}
		public async Task<IActionResult> Index(string search, decimal? minPrice, decimal? maxPrice, int? categoryId, bool? availableOnly)
		{
			var query = _context.Products.Include(p => p.Category).AsQueryable(); // Include Category for filtering

			//   Search by name
			if (!string.IsNullOrEmpty(search))
			{
				query = query.Where(p => p.Name.Contains(search) || p.Description.Contains(search));
			}

			// search product by Price 
			if (minPrice.HasValue)
			{
				query = query.Where(p => p.Price >= minPrice);
			}

			if (maxPrice.HasValue)
			{
				query = query.Where(p => p.Price <= maxPrice);
			}

			//  search product by Category 
			if (categoryId.HasValue)
			{
				query = query.Where(p => p.CategoryID == categoryId);
			}

			//  Availability Filter
			if (availableOnly.HasValue && availableOnly.Value)
			{
				query = query.Where(p => p.StockQuantity > 0);
			}
			var products = await query.ToListAsync();

			//  DropDown of Categories
			ViewBag.Categories = await _context.Categories.ToListAsync();

			return View(products);
		}
		public async Task<IActionResult> Create()
		{
			ViewBag.Categories = await _context.Categories.ToListAsync(); // Load categories
			return View();
		}
		// POST method to Create Product with Category
		[HttpPost]
		public async Task<IActionResult> CreateProduct(Product product)
		{
			ViewBag.Categories = await _context.Categories.ToListAsync(); // Reload the categories 

			_context.Products.Add(product);
			await _context.SaveChangesAsync();
			return RedirectToAction("Index", "Product");
		}
		// GET method of Edit the Product 
		public async Task<IActionResult> Edit(int id)
		{
			var product = await _context.Products.FindAsync(id);
			if (product == null)
				return NotFound();

			return View(product);
		}
		[HttpPost]
		public async Task<IActionResult> Edit(Product product)
		{
			var existingProduct = await _context.Products
				.FirstOrDefaultAsync(p => p.ProductID == product.ProductID);

			if (existingProduct == null)
			{
				return NotFound();
			}
			product.CategoryID = existingProduct.CategoryID;

			var categoryExists = await _context.Categories.AnyAsync(c => c.CategoryID == product.CategoryID);
			if (!categoryExists)
			{
				ModelState.AddModelError("CategoryID", "The selected category does not exist.");
				ViewBag.Categories = await _context.Categories.ToListAsync(); 
				return View(product);
			}
			try
			{
				_context.Entry(existingProduct).CurrentValues.SetValues(product); 
				await _context.SaveChangesAsync();
				return RedirectToAction("Index", "Product");
			}
			catch (DbUpdateException)
			{
				ModelState.AddModelError("", "An error occurred while updating the product. Please check the category selection.");
				ViewBag.Categories = await _context.Categories.ToListAsync();
				return View(product);
			}
		}
		public async Task<IActionResult> Delete(int id)
		{
			var product = await _context.Products.FindAsync(id);
			if (product == null)
			{
				return NotFound();
			}
			_context.Products.Remove(product);
			await _context.SaveChangesAsync();

			return RedirectToAction("Index");
		}
	}
}
